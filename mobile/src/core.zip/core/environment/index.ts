/**
 * @Author: Nicolas Fazio <webmaster-fazio>
 * @Date:   31-05-2017
 * @Email:  contact@nicolasfazio.ch
 * @Last modified by:   webmaster-fazio
 * @Last modified time: 10-06-2017
 */


 export { EnvironmentsModule } from './environment.module';
 export * from '../../environment';
