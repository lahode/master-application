import { Injectable, Inject } from '@angular/core';

import { EnvVariables } from '../../environment/environment.token';
import { IEnvironment } from '../../environment';

@Injectable()
export class EndpointsService {

  _apiEndPoint: string;

  constructor(@Inject(EnvVariables) public envVariables: IEnvironment) {
    this._apiEndPoint = this.envVariables.apiEndpoint;
  }

  getAuth() {
    return this._apiEndPoint + '/api/authenticate';
  }

  getLogin() {
    return this._apiEndPoint + '/login';
  }

  getSignup() {
    return this._apiEndPoint + '/signin';
  }

}
