/**
* @Author: Nicolas Fazio <webmaster-fazio>
* @Date:   19-04-2017
* @Email:  contact@nicolasfazio.ch
 * @Last modified by:   webmaster-fazio
 * @Last modified time: 21-05-2017
*/

import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { Action } from '@ngrx/store';
import { Effect, Actions, toPayload } from "@ngrx/effects";

import { DataActions } from '../actions/dataActions';
import { DatasService } from "../../services/datas-service/datas.service";

@Injectable()
export class DatasEffects {

  constructor(
    private action$: Actions,
    private _database: DatasService
  ) {
  }

  @Effect() loadAction$ = this.action$
      // Listen for the 'GET_DATAS_ARRAY' action
      .ofType(DataActions.GET_DATAS_ARRAY)
      .map<Action, any>(toPayload)
      .switchMap((payload:Observable<any>) => {
        return this._database.getDatasArray(payload)
      })

  @Effect() updateAction$ = this.action$
      // Listen for the 'UPDATE_DATA' action
      .ofType(DataActions.UPDATE_DATA)
      .map<Action, any>(toPayload)
      .switchMap((payload:any) => {
        return this._database.update(payload)
      })

  @Effect() removeAction$ = this.action$
      // Listen for the 'DELETE_DATA' action
      .ofType(DataActions.DELETE_DATA)
      .map<Action, any>(toPayload)
      .switchMap((payload:any) => {
        return this._database.delete(payload)
      })

  @Effect() createAction$ = this.action$
      // Listen for the 'CREATE_DATA' action
      .ofType(DataActions.CREATE_DATA)
      .map<Action, any>(toPayload)
      .switchMap((payload:any) => {
        return this._database.create(payload)
      })

}
