import { Action } from "@ngrx/store";
import { DataActions } from '../actions/dataActions';
import { ITodo } from '../../services/datas-service/datas.service';

export interface IDatasState extends Array<ITodo>{}

export const intitialState:IDatasState = []

export function reducer (state:IDatasState = intitialState, action:any):IDatasState {
  switch (action.type) {
    case DataActions.GET_DATAS_ARRAY: {
      return Object.assign([], state)
    }
    case DataActions.GET_DATAS_ARRAY_SUCCESS: {
      return Object.assign([], [...action.payload])
    }
    case DataActions.UPDATE_DATA_SUCCESS: {
      return Object.assign([], [...state.map((item: any) => {
        return item._id === action.payload.response._id ? action.payload.response : item;
      })])
    }
    case DataActions.DELETE_DATA_SUCCESS: {
      return Object.assign([], [...state.filter((item: any) => {
        return item._id !== action.payload.queryParams.params._id;
      })])
    }
    case DataActions.CREATE_DATA_SUCCESS: {
      return Object.assign([], [...state, action.payload])
    }
    default: {
      return <IDatasState>state;
    }
  }
};
