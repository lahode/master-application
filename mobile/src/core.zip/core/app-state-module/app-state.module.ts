/**
 * @Author: Nicolas Fazio <webmaster-fazio>
 * @Date:   21-05-2017
 * @Email:  contact@nicolasfazio.ch
 * @Last modified by:   webmaster-fazio
 * @Last modified time: 10-08-2017
 */

import { NgModule } from '@angular/core';
import { JwtHelper, AuthConfig, AuthHttp } from "angular2-jwt";
import { Http, HttpModule, RequestOptions } from "@angular/http";

// Import ngrx Tools
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// Import ngRx Store
import { reducer } from './reducers';
import { AuthEffects } from './effects/authEffects';
import { DatasEffects } from './effects/datasEffects';
// import { ErrorEffects } from './effects/errorEffects';

import { AuthActions } from './actions/authActions';
import { DataActions } from './actions/dataActions';

// Import Providers Service
import { StorageService } from "../services/storage-service/storage.service";
import { DatasService } from "../services/datas-service/datas.service";
import { AuthService } from "../services/auth-service/auth.service";
import { EndpointsService } from '../services/auth-service/endpoints';

const providers:Array<any> = [
  StorageService,
  DatasService,
  AuthService,
  EndpointsService,
  JwtHelper,
  {
    provide: AuthHttp,
    useFactory: authHttpServiceFactory,
    deps: [Http, RequestOptions, StorageService]
  }
];
const effects:Array<any> = [
  AuthEffects,
  DatasEffects
];
const actions:Array<any> = [
  AuthActions,
  DataActions
];

// Auth Factory
export function authHttpServiceFactory(http: Http, options: RequestOptions, storage: StorageService) {
  const authConfig = new AuthConfig({
    noJwtError: true,
    globalHeaders: [{'Accept': 'application/json'}],
    tokenGetter: (() => storage.get('jwt')),
  });
  return new AuthHttp(authConfig, http, options);
}

@NgModule({
  imports: [
    HttpModule,
    EffectsModule.forRoot(effects),
    StoreModule.forRoot(reducer),
    StoreDevtoolsModule.instrument()
  ],
  declarations: [],
  providers: [...providers, ...effects, ...actions]
})
export class AppStateModule { }
